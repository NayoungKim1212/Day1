/** 
 * @fileoverview 모바일 전자정부 하이브리드 앱 PKIWizSign API 가이드 프로그램 JavaScript
 * JavaScript. 
 *
 * @author 나신일
 * @version 1.0 
 */

/**
 * iScroll 객체 생성
 * @type iScroll
 */
var myScroll;

/**
 * 인증서 정보 리스트를 담고있는 객체 생성
 * @type JsonArray
 */
var g_certList;

/*********************************************************
 * HTML 및 이벤트 관련 함수
 *********************************************************/

/**
 * 화면을 위한 관련 이벤트
 */
$(function(){
    $.validator.setDefaults({
        submitHandler: function() { 
            if($.mobile.activePage.is('#login')) {
                //3G 사용시 과금이 발생 할 수 있다는 경고 메시지 표시
                if(!fn_egov_network_check(false)) {
                    return;
                }
                // 인증서 인증
                fn_egov_confirm_password();
            }
        }
    });
    
    // validation check
    $("#loginForm").validate();
    
    $(document).on("pageshow", "#importanceList", function(event, ui){
        
        if(myScroll != null) {
            
            myScroll.destroy();
        }
        loaded('wrapperInfo');
    });
    
    $(document).on("pageshow", "#certList", function(event, ui){
        
        if(myScroll != null) {
            
            myScroll.destroy();
        }
        loaded('wrapper');
    });
    
    $(document).on("pageshow", "#loginInfoList", function(event, ui){
        
        if(myScroll != null) {
            
            myScroll.destroy();
        }
        loaded('wrapperList');
    });
});

/**
 * PhoneGap 초기화 이벤트에서 호출하는 function
 * @returns iscroll 과 Back 버튼 event 추가
 * @type
*/
function DeviceAPIInit() {
    loaded('wrapperInfo');
    document.addEventListener("backbutton", backKeyDown, false);
}

/**
 * Android Back 버튼 클릭 이벤트 function.
 * @returns intro or importanceList 화면에서 종료하고 나머지 화면에선 back 처리
 * @type
*/
function backKeyDown(e) {
    if($.mobile.activePage.is('#intro') || $.mobile.activePage.is('#importanceList')){
        
        e.preventDefault();
        navigator.app.exitApp();

    }else{
        navigator.app.backHistory();
    }
}

/**
 * iScroll 적용
 * @returns 
 * @type 
 */
function loaded(scrollTarget) {
    
    // Use this for high compatibility (iDevice + Android)
    setTimeout(function () {
        myScroll = new iScroll(scrollTarget, {
            onBeforeScrollStart : function(e) {
                var target = e.target;
                while (target.nodeType != 1)
                    target = target.parentNode;
    
                if (target.tagName != 'SELECT' && target.tagName != 'INPUT'
                        && target.tagName != 'TEXTAREA')
                    e.preventDefault();
            }
        });
    });

    document.addEventListener('touchmove', function(e) {
        e.preventDefault();
    }, false);
}

/**
 * 서명 성공 Callback function.
 * @returns 서명이 성공하면 사인데이터를 서버에 전달 한다.
 * @type 
*/
function fn_egov_makesign_ok(arg)
{
    console.log('DeviceAPIGuide fn_egov_makesign_ok Success');
    var signedData = arg['signedData'];	    
    var url = "/pki/xml/addPKIInfo.do";
    var acceptType = "xml";
    var params = {uuid :  device.uuid,			
            sign: signedData,
            entrprsSeCode: 'PKI02'};

    alert('Http Method:POST\nacceptType:'+ acceptType + '\n요청데이터:' + JSON.stringify(params));
    
    // get the data from server
    window.plugins.EgovInterface.post(url,acceptType, params, function(xmldata) {		
        console.log('DeviceAPIGuide fn_egov_makesign_ok request Complete');
        alert('응답데이터:' + xmldata);
        if($(xmldata).find("resultState").text() == "OK"){	
            
            window.history.go(-2);
        }else{
            jAlert($(xmldata).find("resultMessage").text(), '오류', 'c');
        }
        
    });	
}

/**
 * 서명 실패 Callback function.
 * @returns 
 * @type
*/
function fn_egov_makesign_fail(arg)
{
    console.log('DeviceAPIGuide fn_egov_makesign_fail Fail');
    alert("Error: \r\n" + error['errMsg']);
}

/**
 * 인증서 리스트 호출 성공 Callback function.
 * @returns 리스트 생성
 * @type
*/
function fn_egov_getcertlistSuccess(result) 
{
    console.log('DeviceAPIGuide fn_egov_getcertlistSuccess Success');
    //Certificates
    g_certList = result['Certificates'];

    var list_html = "";
    for(var i=0 ; i<g_certList.length ; i++) {
        list_html += '<li> ' +
        '<a href="#" onclick="fn_egov_sign_certdata('+i+')">' + g_certList[i]['주체자'] + '<br>' + g_certList[i]['발급자'] + '<br>' + g_certList[i]['만료일'] + '<br>' + '</a> ' +		
        '</li>';
    }
    
    $.mobile.changePage("#certList", "slide", false, false);
    
    var theList = $('#theList');
    theList.html(list_html);	
    theList.listview("refresh");  
}

/**
 * 인증서 리스트 호출 실패 Callback function.
 * @returns
 * @type
*/
function fn_egov_getcertlistFail(errormsg) 
{
    console.log('DeviceAPIGuide fn_egov_getcertlistFail Fail');
    alert("Error: \r\n" + errormsg['errMsg']);
}

/**
 * 인증서 리스트 호출 function.
 * @returns getCertificates call back
 * @type
*/
function fn_egov_go_certlist()
{
    WizSignPG.getCertificates(fn_egov_getcertlistSuccess,fn_egov_getcertlistFail);
}

/**
 * 인증서 정보 innerhtmlArea 생성 function.
 * @returns innerhtmlArea 생성 후 로그인 화면 이동
 * @type
*/
function fn_egov_sign_certdata(iCertIndex)
{
    // 인증서 선택후 화면에 FORM 문을 보여주기 위한 부분
    // 반드시 이 구조를 따를 필요는 없습니다.
    // 선택된 인증서의 INDEX 를 xsigncertindex 로 지정  form 문 밖에 hidden 벨류로 지정해주어야 합니다.
    // 그리고 선택된 인증서의 비밀번호를  xsigncertpassword 로 지정  form 문 밖에서 입력을 받아야 합니다.
    var signForm = '';
    signForm = "" 
        +'주체자 : '+g_certList[iCertIndex]['주체자']+"<br>"
        +'일련번호 : '+g_certList[iCertIndex]['일련번호']+"<br>"
        +'서명알고리즘 : '+g_certList[iCertIndex]['서명알고리즘']+"<br>"
        +'발급자 : '+g_certList[iCertIndex]['발급자']+"<br>"
        +'효력발생일 : '+g_certList[iCertIndex]['효력발생일']+"<br>"
        +'만료일 : '+g_certList[iCertIndex]['만료일']+"<br>";
    
    var certInfo = $('#certInfo');
    certInfo.html(signForm);
    

    //사용자가 선택한 인증서 INDEX (HIDDEN 벨류)
    var signIndex = '';
    signIndex = "" 
        +"<input type=hidden name='xsigncertindex' id='xsigncertindex' value='"+iCertIndex+"'/>";
    
    document.getElementById("innerhtmlArea").innerHTML=signIndex;
    
    $('#loginForm').each(function(){
        this.reset();
    });
   	$.mobile.changePage("#login", "slide", false, false);
}

/**
 * 로그인 버튼 클릭시 인증서 비밀번호 확인 function.
 * @returns 인증서 비밀번호 확인 성공 여부
 * @type  
*/
function fn_egov_confirm_password() {

    var args = new Array();
    args[0] = Number(document.getElementById("xsigncertindex").value) + 1;
    args[1] = $("#loginPasswd").val();
    
    WizSignPG.verifyCertPassword(args, function(result) {
        console.log('DeviceAPIGuide fn_egov_confirm_password Success');
        //Certificates
        var runResult = result['result'];
        var error = result['errMsg'];
        
        if(error!=null){
            alert(error);
            alert(runResult);
        }
        
        if(runResult == 'OK') {
            alert('인증서 비밀번호가 일치합니다.');	
            fn_egov_make_sign();
        }
        
    }, function(error) {
        console.log('DeviceAPIGuide fn_egov_confirm_password Fail');
        alert("Error: \r\n" + error['errMsg']);
    });
}

/**
 * 서명하기 위한 function.
 * @returns 인증서 서명 성공 여부
 * @type  
*/
function fn_egov_make_sign()
{
    var args = new Array();
    args[0] = Number(document.getElementById("xsigncertindex").value) + 1;
    args[1] = $("#loginPasswd").val();
    args[2] = "usrId=&password=&name=";
    
    WizSignPG.doSignature(args, fn_egov_makesign_ok, fn_egov_makesign_fail);
}

/**
 * Login Info List 화면 이동 function.
 * @returns 서버에 저장된 로그인 로그 정보를 요청받아 XML 리스트 반환한다.
 * @type  
*/
function fn_egov_go_loginInfoList()
{
    //3G 사용시 과금이 발생 할 수 있다는 경고 메시지 표시
    if(!fn_egov_network_check(false)) {
        return;
    }
    
    $.mobile.changePage("#loginInfoList", "slide", false, false);
    
    var url = "/pki/xml/pkiInfoList.do";
    var accept_type = "xml";
    // get the data from server
    window.plugins.EgovInterface.post(url,accept_type, null, function(xmldata) {
        console.log('DeviceAPIGuide fn_egov_go_loginInfoList request Complete');
        var list_html = "";
        
        $(xmldata).find("pkiInfoList").each(function(){
            var dn = $(this).find("dn").text();
            var date = $(this).find("crtfcDt").text();
            var entrprsSeCode = $(this).find("entrprsSeCode").text().replace(/\s+$/, "");
            var entrprsSe = "NONE";
            if(entrprsSeCode == 'PKI01') {
                entrprsSe = "MagicXSign";
            } else if(entrprsSeCode == 'PKI02') {
                entrprsSe = "WizSign";
            } else if(entrprsSeCode == 'PKI03') {
                entrprsSe = "XecureSmart";
            }

            list_html += "<li><h3>subjdn : " + dn + "</h3>";
            list_html += "<p><strong>Date : " + date + "</strong></p>";
            list_html += "<p><strong>NPKI : " + entrprsSe + "</strong></p></li>";
            });
        var theList = $('#theLogList');
        theList.html(list_html);
        theList.listview("refresh");
        myScroll.refresh();
    });
}